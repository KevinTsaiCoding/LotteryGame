#ifndef BIGLOTTO_PC_H
#define BIGLOTTO_PC_H
void biglotto_pc(void);
#endif
