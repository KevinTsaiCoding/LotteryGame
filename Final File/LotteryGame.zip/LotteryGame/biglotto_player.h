#ifndef BIG_LOTTO_PLAYER_H
#define BIG_LOTTO_PLAYER_H
void biglotto_player(void);
#endif
