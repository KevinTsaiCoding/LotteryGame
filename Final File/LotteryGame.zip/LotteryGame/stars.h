#ifndef STARS_H
#define STARS_H
void stars(void);
#endif
