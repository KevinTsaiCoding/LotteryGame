#ifndef BIGLOTTO_H
#define BIGLOTTO_H
void biglotto(void);
#endif
